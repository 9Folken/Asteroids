﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asteroids
{
    class Star:BaseObject
    {
        public Star(Point pos, Point dir, Size size) : base(pos, dir, size){}

        

        public override void Draw​()
        {
            
            //Game​.Buffer​.Graphics​.DrawLine​(Pens​.White​,Pos​.X​, Pos​.Y, Pos​.X​​ + Size​.Width​, Pos​.Y + Size​.Height​);
            //Game​.Buffer​.Graphics​.DrawLine​(Pens​.White​, Pos​.X​​ + Size​.Width​, Pos​.Y​, Pos​.X​, Pos​.Y​​ + Size​.Height​);

            //private void drawStar(Point cord, Graphics g, int size)
            //{
                Random r = new Random(DateTime.Now.Millisecond);
                Color color = Color.FromArgb(r.Next(0, 255), r.Next(0, 255), r.Next(0, 255));
                SplashScreen.Buffer​.Graphics.DrawLine(new Pen(color), Pos.X - Size.Width, Pos.Y, Pos.X + Size.Width, Pos.Y);
                SplashScreen.Buffer​.Graphics.DrawLine(new Pen(color), Pos.X, Pos.Y - Size.Height, Pos.X, Pos.Y + Size.Height);
            //}

        }

        public override void Update​()
        {
            //Random r = new Random();
            //Pos.X = Pos.X + Dir.X;
            //Pos.Y = Pos.Y + Dir.Y;
            //if (Pos.X < 0) Dir.X = -Dir.X;
            //if (Pos.X > Game.Width) Dir.X = -Dir.X;
            //if (Pos.Y < 0) Dir.Y = -Dir.Y;
            //if (Pos.Y > Game.Height) Dir.Y = -Dir.Y;

            Pos​.X​​ = (Pos​.X​​ + Dir​.X);
            
            if (Pos.X < 0) Pos.X = SplashScreen.Width + Size.Width;
            //if (Pos.X < 0) Dir.X = -Dir.X;
         //   if (Pos.X > Game.Width) Dir.X = -Dir.X;
        }
    }
}
