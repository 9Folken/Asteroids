﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    public abstract class Employee:IComparable<Employee>,IComparer<Employee>
    {
        /// <summary>
        /// Конструктор объекта сотрудник
        /// </summary>
        /// <param name="name">имя сотрудника</param>
        /// <param name="salary">зарплата сотрудника в месяц</param>
        public Employee(string name, double salary)
        {
            Name = name;
            Salary = salary;
        }
        private string name;
        private double salary;
        //private int _i = -1;

        public string Name { get => name; set => name = value; }
        public double Salary { get => salary; set => salary = SetSalaryMonth(value); }

        //public object Current => throw new NotImplementedException();

        public abstract double SetSalaryMonth(double salary);

        int IComparable<Employee>.CompareTo(Employee other)
        {
            if (Salary < other.Salary) return 1;
            if (Salary > other.Salary) return -1;
            return 0;
        }

        int IComparer<Employee>.Compare(Employee x, Employee y)
        {
            if (x.Salary.CompareTo(y.Salary) != 0)
                return x.Salary.CompareTo(y.Salary);           
           
                return 0;
           
        }

      
    }
}
