﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    class EmployeeByMonth:Employee
    {
        private double salaryMonth;
        public EmployeeByMonth(string name, int salary) : base(name, salary) { }

        public override double SetSalaryMonth(double salary)
        {
            return salaryMonth = salary;
        }
    }
}
