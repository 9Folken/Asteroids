﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asteroids
{
    class Galaxy:BaseObject
    {
        public Galaxy(Point pos, Point dir, Size size) : base(pos, dir, size) { }

        public override void Draw​()
        {
            Image newImage = Image.FromFile("galaxy.png");
            SplashScreen.Buffer​.Graphics.DrawImage(newImage, Pos.X - Size.Width, Pos.Y - Size.Height, 25, 25);
        }

        public override void Update​()
        {
            Pos​.X​​ = (Pos​.X​​ + Dir​.X);
            if (Pos.X < 0) Pos.X = SplashScreen.Width + Size.Width;
        }
    }
}
