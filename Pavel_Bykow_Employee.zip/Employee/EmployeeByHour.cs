﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    
    public class EmployeeByHour:Employee
    {

        private double salaryMonth;

        public EmployeeByHour(string name, int salary) : base(name, salary) { }


        public override double SetSalaryMonth(double salaryHour)
        {
            salaryMonth = 20.8 * 8 * salaryHour;
            return salaryMonth;
        }
    }
}
