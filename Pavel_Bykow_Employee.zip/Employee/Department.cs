﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
   public class Department:IEnumerable,IEnumerator
    {
        
        public Department()
        {
            _employeesArray = new Employee[10];
            _employeesArray[0] = new EmployeeByHour("Jack", 20);
            _employeesArray[1] = new EmployeeByMonth("Jane", 2500);
            _employeesArray[2] = new EmployeeByHour("Alex", 15);
            _employeesArray[3] = new EmployeeByMonth("Tom", 2400);
            _employeesArray[4] = new EmployeeByHour("Kate", 25);
            _employeesArray[5] = new EmployeeByHour("Daniel", 16);
            _employeesArray[6] = new EmployeeByMonth("Ted", 4500);
            _employeesArray[7] = new EmployeeByHour("Jessy", 12);
            _employeesArray[8] = new EmployeeByHour("Polly", 21);
            _employeesArray[9] = new EmployeeByMonth("Sheila", 1800);
        }



        private Employee[] _employeesArray;
        private int _i = -1;

        public object Current => _employeesArray[_i];

        public IEnumerator GetEnumerator()
        {
            return this;
        }

        public void Sort()
        {
            Array.Sort(_employeesArray);
        }

        public bool MoveNext()
        {
            
            if (_i == _employeesArray.Length - 1)
            {
                Reset();
                return false;
            }
            _i++;
            return true;
        }

        public void Reset()
        {
            _i = -1;
        }
    }
}
